#ifndef WEB_SERVER_H
#define WEB_SERVER_H
// =====================================================================================================
// webServer.h - Wi-Fi + HTTP server that shows the IR array image and the camera in a browser on another device
//
// Default: the board creates its own Wi-Fi network (access point). Join "IR-Array" from a phone or laptop and
// open http://192.168.4.1/ (the address is also printed in the serial log). Set WEB_JOIN_NETWORK to 1 to join an
// existing WPA2 network instead; the log then prints the address the router gave the board.
//   GET /            the page (main/index.html, built into the firmware)
//   GET /frame       latest IR image as JSON: {"seq":n,"ta":C,"period":ms,"w":32,"h":24,"t":[768 temperatures in C]}
//   GET /camera.jpg  a fresh camera snapshot (400 x 300 JPEG), made on its own task so it never delays /frame
//   GET /gas         latest MiCS-4514 reading as JSON (mics4514.h): state, mV / Rs / R0 per element, ppm per gas
//   POST /gas/baseline  take a new clean-air baseline R0
//
// References:
//  [WIFI]  ESP-IDF v6.1 examples/wifi/getting_started/softAP and .../station (Public Domain / CC0)
//  [HTTPD] ESP-IDF v6.1 components/esp_http_server/include/esp_http_server.h
//  [BUILD] ESP-IDF v6.1 docs/en/api-guides/build-system.rst, "Embedding Binary Data"
//  [ASYNC] ESP-IDF v6.1 examples/protocols/http_server/async_handlers (Public Domain / CC0):
//          httpd_req_async_handler_begin() hands a request to another task, httpd_req_async_handler_complete() ends it
// =====================================================================================================

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "esp_check.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "irArray.h"
#include "camera.h"
#include "mics4514.h"

// ---- Wi-Fi settings -------------------------------------------------------------------------------
#define WEB_JOIN_NETWORK 0            // 0 = the board makes its own network, 1 = join WEB_STA_SSID
#define WEB_AP_SSID "Chiron_CAMERAS"  // network name when the board makes its own network
#define WEB_AP_PASSWORD "change-me-please" // WPA2 needs 8-63 characters - change it
#define WEB_AP_CHANNEL 6
#define WEB_AP_MAX_CLIENTS 4
#define WEB_STA_SSID "your-network" // only used when WEB_JOIN_NETWORK is 1 (WPA2-Personal; not eduroam-style logins)
#define WEB_STA_PASSWORD "your-password"

#define WEB_CAMERA_QUEUE 2    // camera requests that may wait for the camera task (more get their connection closed)
#define WEB_CAMERA_STACK 8192 // camera task stack; the JPEG encoder runs on it

static const char *TAG_WEB = "WEB";
static QueueHandle_t webCameraQueue = NULL;

// index.html is linked into the firmware by EMBED_TXTFILES in main/CMakeLists.txt, as a null-terminated
// string between these two symbols [BUILD]
extern const char webIndexStart[] asm("_binary_index_html_start");
extern const char webIndexEnd[] asm("_binary_index_html_end");

// Logs devices joining/leaving, and keeps a joined network connected [WIFI softAP and station event handlers]
static void webWifiEvent(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STACONNECTED)
    {
        ESP_LOGI(TAG_WEB, "A device joined %s", WEB_AP_SSID);
    }
    else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STADISCONNECTED)
    {
        ESP_LOGI(TAG_WEB, "A device left %s", WEB_AP_SSID);
    }
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START)
    {
        esp_wifi_connect();
    }
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED)
    {
        ESP_LOGW(TAG_WEB, "Not connected to %s - retrying", WEB_STA_SSID);
        esp_wifi_connect();
    }
    else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP)
    {
        const ip_event_got_ip_t *event = (const ip_event_got_ip_t *)data;
        ESP_LOGI(TAG_WEB, "Connected to %s. On a device on the same network, open http://" IPSTR "/", WEB_STA_SSID,
                 IP2STR(&event->ip_info.ip));
    }
}

// Starts Wi-Fi, following the order of the ESP-IDF examples [WIFI]
static void webStartWifi(void)
{
    // Wi-Fi stores its calibration data in NVS; erase and retry if the partition is full or from an older layout
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    const wifi_init_config_t initConfig = WIFI_INIT_CONFIG_DEFAULT();

#if WEB_JOIN_NETWORK
    esp_netif_create_default_wifi_sta();
    ESP_ERROR_CHECK(esp_wifi_init(&initConfig));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &webWifiEvent, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &webWifiEvent, NULL, NULL));
    wifi_config_t wifiConfig = {
        .sta = {
            .ssid = WEB_STA_SSID,
            .password = WEB_STA_PASSWORD,
            .threshold.authmode = WIFI_AUTH_WPA2_PSK, // ignore networks weaker than WPA2
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifiConfig));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG_WEB, "Joining Wi-Fi network %s ...", WEB_STA_SSID);
#else
    esp_netif_t *ap = esp_netif_create_default_wifi_ap();
    ESP_ERROR_CHECK(esp_wifi_init(&initConfig));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &webWifiEvent, NULL, NULL));
    wifi_config_t wifiConfig = {
        .ap = {
            .ssid = WEB_AP_SSID,
            .ssid_len = sizeof(WEB_AP_SSID) - 1,
            .channel = WEB_AP_CHANNEL,
            .password = WEB_AP_PASSWORD,
            .max_connection = WEB_AP_MAX_CLIENTS,
            .authmode = WIFI_AUTH_WPA2_PSK,
            .pmf_cfg = {.required = false}, // allow devices without protected management frames to join
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifiConfig));
    ESP_ERROR_CHECK(esp_wifi_start());

    esp_netif_ip_info_t ip = {0};
    esp_netif_get_ip_info(ap, &ip);
    ESP_LOGI(TAG_WEB, "Wi-Fi network %s is up (password %s). Join it, then open http://" IPSTR "/", WEB_AP_SSID,
             WEB_AP_PASSWORD, IP2STR(&ip.ip));
#endif
}

// GET / - the page
static esp_err_t webIndexGet(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, webIndexStart, webIndexEnd - webIndexStart - 1); // -1: leave out the trailing NUL
}

// GET /frame - the latest image as JSON, sent one row per chunk so no large buffer is needed [HTTPD
// httpd_resp_send_chunk]. Temperatures have one decimal; a non-finite value is sent as null so the JSON stays valid.
static esp_err_t webFrameGet(httpd_req_t *req)
{
    static float to[IR_PIXELS]; // static: the server handles one request at a time, in its own task
    float ta = 0.0f;
    uint32_t seq = 0;

    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    if (!irArrayGetLatest(to, &ta, &seq))
    {
        httpd_resp_set_status(req, "503 Service Unavailable");
        return httpd_resp_sendstr(req, "{\"error\":\"no image yet\"}");
    }

    char buf[IR_COLS * 8 + 96]; // one row: 32 values of at most 7 characters plus a comma
    int n = snprintf(buf, sizeof(buf), "{\"seq\":%lu,\"ta\":%.2f,\"period\":%lu,\"w\":%d,\"h\":%d,\"t\":[",
                     (unsigned long)seq, ta, (unsigned long)irArraySubpageMs(), IR_COLS, IR_ROWS);
    ESP_RETURN_ON_ERROR(httpd_resp_send_chunk(req, buf, n), TAG_WEB, "send failed");

    for (int row = 0; row < IR_ROWS; row++)
    {
        n = 0;
        for (int col = 0; col < IR_COLS; col++)
        {
            const float v = to[row * IR_COLS + col];
            const char *sep = (row == IR_ROWS - 1 && col == IR_COLS - 1) ? "" : ",";
            n += isfinite(v) ? snprintf(buf + n, sizeof(buf) - n, "%.1f%s", v, sep)
                             : snprintf(buf + n, sizeof(buf) - n, "null%s", sep);
        }
        ESP_RETURN_ON_ERROR(httpd_resp_send_chunk(req, buf, n), TAG_WEB, "send failed");
    }

    ESP_RETURN_ON_ERROR(httpd_resp_send_chunk(req, "]}", 2), TAG_WEB, "send failed");
    return httpd_resp_send_chunk(req, NULL, 0); // a zero-length chunk ends the response [HTTPD]
}

// Answers camera requests one at a time: capture (usually already waiting, see cameraCapture), JPEG, send [ASYNC].
// The server task only queues them, so /frame is answered while a snapshot is being made or sent.
static void webCameraTask(void *arg)
{
    (void)arg;
    for (;;)
    {
        httpd_req_t *req = NULL;
        xQueueReceive(webCameraQueue, &req, portMAX_DELAY);
        const uint8_t *jpg = NULL;
        size_t len = 0;
        httpd_resp_set_hdr(req, "Cache-Control", "no-store");
        if (cameraJpeg(&jpg, &len, CAM_CAPTURE_TIMEOUT_MS) == ESP_OK)
        {
            httpd_resp_set_type(req, "image/jpeg");
            httpd_resp_send(req, (const char *)jpg, len); // fails only if the browser has gone; nothing to do then
        }
        else
        {
            httpd_resp_set_status(req, "503 Service Unavailable");
            httpd_resp_set_type(req, "text/plain");
            httpd_resp_sendstr(req, "camera not available");
        }
        httpd_req_async_handler_complete(req); // the server may reuse or close the socket again [ASYNC]
    }
}

// GET /camera.jpg - hands the request to webCameraTask [ASYNC]
static esp_err_t webCameraGet(httpd_req_t *req)
{
    httpd_req_t *copy = NULL;
    ESP_RETURN_ON_ERROR(httpd_req_async_handler_begin(req, &copy), TAG_WEB, "camera request copy");
    if (xQueueSend(webCameraQueue, &copy, 0) != pdTRUE)
    {
        httpd_req_async_handler_complete(copy);
        return ESP_FAIL; // queue full: the server closes this connection [ASYNC]
    }
    return ESP_OK;
}

// Appends printf-style text to buf; *n keeps counting past the end, so *n >= size means it did not fit
static void __attribute__((format(printf, 4, 5))) webAppend(char *buf, size_t size, int *n, const char *fmt, ...)
{
    if (*n < (int)size)
    {
        va_list args;
        va_start(args, fmt);
        *n += vsnprintf(buf + *n, size - *n, fmt, args);
        va_end(args);
    }
}

// A JSON number with 4 significant digits, or null when not finite; out must hold 16 characters
static const char *webJsonNum(char *out, float v)
{
    if (!isfinite(v))
    {
        return "null";
    }
    snprintf(out, 16, "%.4g", v);
    return out;
}

// GET /gas - latest MiCS-4514 reading: {"seq","state","left","cal","sensors":[{name,mv,rs,r0,over}],
// "gases":[{name,formula,sensor,ppm,lo,hi}]}; Rs and R0 in kOhm, null = not available
static esp_err_t webGasGet(httpd_req_t *req)
{
    static char buf[1024]; // static: the server handles one request at a time, in its own task
    micsReading_t r;
    char a[16], b[16], c[16];
    int n = 0;

    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    if (!mics4514GetLatest(&r))
    {
        httpd_resp_set_status(req, "503 Service Unavailable");
        return httpd_resp_sendstr(req, "{\"error\":\"gas sensor not running\"}");
    }
    webAppend(buf, sizeof(buf), &n, "{\"seq\":%lu,\"state\":\"%s\",\"left\":%lu,\"cal\":%s,\"sensors\":[",
              (unsigned long)r.seq, micsStateName[r.state], (unsigned long)r.secondsLeft, r.calibrated ? "true" : "false");
    for (int s = 0; s < 2; s++)
    {
        const micsSensor_t *e = &r.sensor[s];
        webAppend(buf, sizeof(buf), &n, "%s{\"name\":\"%s\",\"mv\":%s,\"rs\":%s,\"r0\":%s,\"over\":%s}", s ? "," : "",
                  s == MICS_RED ? "RED" : "OX", webJsonNum(a, e->mv), webJsonNum(b, e->rs), webJsonNum(c, e->r0),
                  e->over ? "true" : "false");
    }
    webAppend(buf, sizeof(buf), &n, "],\"gases\":[");
    for (size_t g = 0; g < MICS_GASES; g++)
    {
        const micsGas_t *gas = &micsGases[g];
        webAppend(buf, sizeof(buf), &n, "%s{\"name\":\"%s\",\"formula\":\"%s\",\"sensor\":\"%s\",\"ppm\":%s,\"lo\":%s,\"hi\":%s}",
                  g ? "," : "", gas->name, gas->formula, gas->sensor == MICS_RED ? "RED" : "OX", webJsonNum(a, r.ppm[g]),
                  webJsonNum(b, gas->lo), webJsonNum(c, gas->hi));
    }
    webAppend(buf, sizeof(buf), &n, "]}");
    if (n >= (int)sizeof(buf))
    {
        return httpd_resp_send_500(req);
    }
    return httpd_resp_send(req, buf, n);
}

// POST /gas/baseline - the sensor is in clean air: take a new R0
static esp_err_t webGasBaselinePost(httpd_req_t *req)
{
    if (mics4514RequestBaseline() != ESP_OK)
    {
        httpd_resp_set_status(req, "503 Service Unavailable");
        return httpd_resp_sendstr(req, "gas sensor not running");
    }
    httpd_resp_set_status(req, "202 Accepted");
    return httpd_resp_send(req, NULL, 0);
}

// GET /favicon.ico - browsers ask for it; answer "no content" instead of logging a 404
static esp_err_t webFaviconGet(httpd_req_t *req)
{
    httpd_resp_set_status(req, "204 No Content");
    return httpd_resp_send(req, NULL, 0);
}

// Starts the camera task, then the HTTP server on port 80, and registers the pages [HTTPD, ASYNC]
static esp_err_t webStartHttp(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.lru_purge_enable = true; // reuse the least recently used socket when a phone leaves connections open
    webCameraQueue = xQueueCreate(WEB_CAMERA_QUEUE, sizeof(httpd_req_t *));
    if (webCameraQueue == NULL || xTaskCreate(webCameraTask, "webCamera", WEB_CAMERA_STACK, NULL, config.task_priority,
                                              NULL) != pdPASS)
    {
        return ESP_ERR_NO_MEM;
    }

    httpd_handle_t server = NULL;
    ESP_RETURN_ON_ERROR(httpd_start(&server, &config), TAG_WEB, "HTTP server did not start");

    const httpd_uri_t pages[] = {
        {.uri = "/", .method = HTTP_GET, .handler = webIndexGet},
        {.uri = "/frame", .method = HTTP_GET, .handler = webFrameGet},
        {.uri = "/camera.jpg", .method = HTTP_GET, .handler = webCameraGet},
        {.uri = "/gas", .method = HTTP_GET, .handler = webGasGet},
        {.uri = "/gas/baseline", .method = HTTP_POST, .handler = webGasBaselinePost},
        {.uri = "/favicon.ico", .method = HTTP_GET, .handler = webFaviconGet},
    }; // 6 of the default 8 handler slots [HTTPD HTTPD_DEFAULT_CONFIG max_uri_handlers]
    for (size_t i = 0; i < sizeof(pages) / sizeof(pages[0]); i++)
    {
        ESP_RETURN_ON_ERROR(httpd_register_uri_handler(server, &pages[i]), TAG_WEB, "could not register %s", pages[i].uri);
    }
    ESP_LOGI(TAG_WEB, "HTTP server running on port %d", config.server_port);
    return ESP_OK;
}

// Wi-Fi first, then the HTTP server
static inline esp_err_t webServerStart(void)
{
    webStartWifi();
    return webStartHttp();
}

#endif // WEB_SERVER_H

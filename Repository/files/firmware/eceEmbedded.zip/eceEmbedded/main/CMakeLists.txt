idf_component_register(
    SRCS
        "main.c"
    INCLUDE_DIRS
        "."
    EMBED_TXTFILES
        "index.html"                  # web page served at http://<board>/ (webServer.h)
    REQUIRES
        espressif__esp_cam_sensor     # OV5640 driver + SCCB (camera.h); version set in idf_component.yml
        esp_driver_i2c
        mlx90640                      # Melexis MLX90640 library (components/mlx90640)
    PRIV_REQUIRES
        esp_driver_gptimer
        esp_driver_gpio
        esp_driver_cam                # DVP camera receiver (camera.h)
        espressif__esp_new_jpeg       # JPEG encoder for the web snapshots (camera.h); version set in idf_component.yml
        esp_timer                     # frame timing in the camera interrupt (camera.h)
        esp_adc                       # gas sensor voltages (mics4514.h)
        esp_wifi                      # Wi-Fi (webServer.h)
        esp_netif
        esp_event
        nvs_flash
        esp_http_server               # HTTP server (webServer.h)
)

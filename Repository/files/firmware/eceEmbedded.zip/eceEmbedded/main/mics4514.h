#ifndef MICS4514_H
#define MICS4514_H
// =====================================================================================================
// mics4514.h - SGX Sensortech MiCS-4514 gas sensor: RED element (reducing gases) + OX element (oxidising gases)
//
// Does:  preheats the OX element, reads both elements with ADC1 once per second, converts each voltage to the
//        sensing resistance Rs, takes a clean-air baseline R0 after the warm-up (or when asked), and estimates the
//        gases the datasheet lists from Rs/R0. Publishes the latest reading (mics4514GetLatest(), used by webServer.h).
// Board: both heaters run from +3.3 V through fixed resistors whenever the board has power; firmware only switches
//        the OX preheat FET [SCH]. With the typical heater resistances 74 / 66 Ohm [DS p.3]:
//          RED          3.3 V / (74 + 30 Ohm)      = 31.7 mA -> 74 mW   (datasheet 71-81 mW [DS p.3])
//          OX           3.3 V / (66 + 33 + 30 Ohm) = 25.6 mA -> 43 mW   (datasheet 30-50 mW [DS p.3])
//          OX, PRE_S=1  3.3 V / (66 + 33 Ohm)      = 33.3 mA -> 73 mW   (Q1 shorts R1; preheat only [AN2])
// Limits: R0 differs per part (RED 100-1500 kOhm, OX 0.8-20 kOhm [DS p.2]), so ppm needs a baseline taken in clean
//         air. Estimates use the datasheet's typical curves (25 C, 50 % RH [DS p.1]) and each assumes its gas is the
//         only one present. Those curves give 4.4 ppm CO and 0.16 ppm NO2 at Rs/R0 = 1, so readings near the
//         baseline mean "about that or less". Sensitivity varies widely per part (S60 1.2-50 [DS p.2]).
//         No temperature or humidity correction.
//
// References used in the comments below:
//  [DS]   SGX Sensortech, MiCS-4514 Data Sheet 0278 rev 15
//  [AN2]  SGX Sensortech, MiCS Application Note 2, "Frequently Asked Questions for MiCS Gas Sensors",
//         A1A-MiCS_AN2 Version 1, Aug 2007, p.2  https://www.farnell.com/datasheets/3935704.pdf
//  [DFR]  DFRobot SEN0377 (MiCS-4514 board) wiki, "The sensor takes 3 minutes to warm up", and its library,
//         DFRobot_MICS.cpp L16-40: warmUpTime() takes R0 from a reading once that time is over
//         https://wiki.dfrobot.com/_SKU_SEN0377_Gravity__MEMS_Gas_Sensor_CO__Alcohol__NO2___NH3___I2C___MiCS_4514
//         https://github.com/DFRobot/DFRobot_MICS
//  [SCH]  Sensor board schematic (R1-R5, Q1 AO3400A, R12, J1/J2) and main board (IO6, IO7, IO47, C11, C12)
//  [S3DS] Espressif, ESP32-S3 Series Datasheet v2.0, 5.5 ADC Characteristics, p.65, Tables 5-5 and 5-6
//  [ADC]  ESP-IDF v6.1 components/esp_adc (adc_oneshot.h, adc_cali_scheme.h, adc_cali_curve_fitting.c L78-80),
//         examples/peripherals/adc/oneshot_read, components/soc/esp32s3/include/soc/adc_channel.h L24-28
//  [V44]  ESP-IDF v4.4 ESP32-S3 ADC page, nominal ranges: DB_0 0-950 mV, DB_11 (= DB_12) 0-3100 mV
//         https://docs.espressif.com/projects/esp-idf/en/v4.4/esp32s3/api-reference/peripherals/adc.html
//  [FIT]  Rs/R0 = a * ppm^b, least-squares fits (log-log) to the curves on [DS] p.1, taken from the PDF's vector
//         paths; largest deviation 0.005-0.024 decades. Cross-check: Seeed's MiCS-6814 library (same RED/OX curves)
//         uses CO 4.385*x^-1.179, NO2 x^1.007/6.855, CH4 630.957*x^-4.363, H2 0.73*x^-1.8, C2H5OH 1.622*x^-1.552
//         (x = Rs/R0); these fits give 4.420*x^-1.1885, x^0.9933/6.431, 749.4*x^-4.3085, 0.817*x^-1.7721, 1.602*x^-1.5542
//         https://github.com/Seeed-Studio/Mutichannel_Gas_Sensor MutichannelGasSensor.cpp L333-361
// =====================================================================================================

#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "driver/gpio.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_check.h"
#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

// ---- Board [SCH] ----------------------------------------------------------------------------------
#define MICS_RED_IO 6              // VRED  -> IO6 = ADC1 channel 5 [ADC adc_channel.h]
#define MICS_OX_IO 7               // VNOx  -> IO7 = ADC1 channel 6
#define MICS_PRE_IO 47             // PRE_S -> Q1 gate; R12 (100 kOhm) holds it off while the ESP32 resets
#define MICS_VCC_MV 3300.0f        // divider supply (+3.3 V); enter the measured rail for a more exact Rs
#define MICS_RED_LOAD_OHM 10000.0f // R4: VRED = Vcc * R4 / (Rs + R4). RLOAD must be >= 820 Ohm [DS p.3]
#define MICS_OX_LOAD_OHM 1000.0f   // R3: VNOx = Vcc * R3 / (Rs + R3)

// ---- Timing ---------------------------------------------------------------------------------------
#define MICS_PREHEAT_S 30   // PRE_S high for 30 s: "the NO2 sensor is preheated (normally operated at 40 mW) at 80 mW
                            // for 30 seconds before use" [AN2 p.2]. 0 = no preheat
#define MICS_WARMUP_S 180   // automatic baseline 3 min after start [DFR]
#define MICS_BASELINE_S 10  // R0 = mean Rs of this many readings
#define MICS_PERIOD_MS 1000 // one reading per second
#define MICS_LOG_EVERY_S 10 // summary line in the serial log

// ---- ADC [S3DS Tables 5-5, 5-6; the board has the 100 nF per pin those tables were measured with] -----------
#define MICS_SAMPLES 64      // averaged per reading: "sample multiple times ... or calculate the average value"
#define MICS_LOW_MAX_MV 750  // ATTEN0 (0-850 mV, +-5 mV) when the ATTEN3 probe reads <= 750 mV
                             // (850 mV - 50 mV ATTEN3 error - 50 mV margin); otherwise ATTEN3 (0-2900 mV, +-50 mV)
#define MICS_HIGH_MAX_MV 2900 // above: outside ATTEN3's specified range, reading flagged approximate
#define MICS_MIN_MV 1.0f      // below: no usable signal (Rs > 33 MOhm RED, > 3.3 MOhm OX)
#define MICS_TASK_STACK 4096
#define MICS_TASK_PRIORITY 4

// ---- Gases [DS p.1 "Detectable gases"], curves [FIT] --------------------------------------------------
enum { MICS_RED = 0, MICS_OX = 1 };

typedef struct
{
    const char *name;
    const char *formula;
    int sensor;     // MICS_RED or MICS_OX
    float a, b;     // Rs/R0 = a * ppm^b
    float lo, hi;   // ppm shown: datasheet detection range, limited to where the curve is drawn
} micsGas_t;

static const micsGas_t micsGases[] = {
    {"Carbon monoxide", "CO", MICS_RED, 3.4919f, -0.8414f, 1.0f, 1000.0f},     // DS 1-1000;   curve 0.31-1040
    {"Ethanol", "C2H5OH", MICS_RED, 1.3540f, -0.6434f, 10.0f, 99.0f},         // DS 10-500;   curve 1.4-99
    {"Hydrogen", "H2", MICS_RED, 0.8922f, -0.5643f, 1.12f, 246.0f},           // DS 1-1000;   curve 1.12-246
    {"Ammonia", "NH3", MICS_RED, 0.9777f, -0.2228f, 1.0f, 149.0f},            // DS 1-500;    curve 1-149
    {"Methane", "CH4", MICS_RED, 4.6475f, -0.2321f, 2980.0f, 12900.0f},       // DS >1000;    curve 2980-12900
    {"Nitrogen dioxide", "NO2", MICS_OX, 6.5112f, 1.0067f, 0.05f, 6.41f},     // DS 0.05-10;  curve 0.0101-6.41
};
#define MICS_GASES (sizeof(micsGases) / sizeof(micsGases[0]))

// ---- Published reading ----------------------------------------------------------------------------
typedef enum { MICS_PREHEAT, MICS_WARMUP, MICS_BASELINE, MICS_READY } micsState_t;
static const char *const micsStateName[] = {"preheat", "warmup", "baseline", "ready"};

typedef struct
{
    float mv;  // mean voltage at the ESP32 pin, mV
    float rs;  // sensing resistance, kOhm (NAN: no signal)
    float r0;  // clean-air baseline, kOhm (NAN: not taken yet)
    bool over; // voltage above the ADC's specified range: rs approximate
} micsSensor_t;

typedef struct
{
    uint32_t seq;           // reading number, 0 = none yet
    micsState_t state;
    uint32_t secondsLeft;   // of the preheat, warm-up or baseline
    bool calibrated;        // ADC eFuse calibration in use
    micsSensor_t sensor[2]; // [MICS_RED], [MICS_OX]
    float ppm[MICS_GASES];  // per micsGases[] entry (NAN: no baseline or no signal)
} micsReading_t;

static const char *TAG_MICS = "MICS4514";
static adc_oneshot_unit_handle_t micsAdc = NULL;
static adc_channel_t micsChan[2];
static adc_atten_t micsAtten[2];                     // attenuation each channel is set to
static adc_cali_handle_t micsCali[2] = {NULL, NULL}; // [0] ATTEN0, [1] ATTEN3
static SemaphoreHandle_t micsLock = NULL;            // guards the two below
static micsReading_t micsPub;
static bool micsBaselineAsked = false;

// One raw sample in mV: eFuse curve-fitting calibration [ADC], or the nominal range [V44] on a chip without it
static int micsToMv(adc_atten_t atten, int raw)
{
    const int i = (atten == ADC_ATTEN_DB_0) ? 0 : 1;
    int mv = 0;
    if (micsCali[i] != NULL && adc_cali_raw_to_voltage(micsCali[i], raw, &mv) == ESP_OK)
    {
        return mv;
    }
    return raw * (i == 0 ? 950 : 3100) / 4095;
}

// Sets a channel's attenuation if it differs; returns the attenuation in effect
static adc_atten_t micsSetAtten(int s, adc_atten_t atten)
{
    if (micsAtten[s] != atten)
    {
        const adc_oneshot_chan_cfg_t cfg = {.atten = atten, .bitwidth = ADC_BITWIDTH_12};
        if (adc_oneshot_config_channel(micsAdc, micsChan[s], &cfg) == ESP_OK)
        {
            micsAtten[s] = atten;
        }
    }
    return micsAtten[s];
}

// Mean voltage (mV) of one element: an ATTEN3 probe picks the range, then MICS_SAMPLES samples are averaged
static float micsReadMv(int s, bool *over)
{
    int raw = 0;
    adc_atten_t atten = micsSetAtten(s, ADC_ATTEN_DB_12);
    if (adc_oneshot_read(micsAdc, micsChan[s], &raw) == ESP_OK && micsToMv(atten, raw) <= MICS_LOW_MAX_MV)
    {
        atten = micsSetAtten(s, ADC_ATTEN_DB_0);
    }
    int sum = 0;
    int n = 0;
    for (int i = 0; i < MICS_SAMPLES; i++)
    {
        if (adc_oneshot_read(micsAdc, micsChan[s], &raw) == ESP_OK)
        {
            sum += micsToMv(atten, raw);
            n++;
        }
    }
    const float mv = (n > 0) ? (float)sum / (float)n : NAN;
    *over = (atten != ADC_ATTEN_DB_0 && mv > MICS_HIGH_MAX_MV);
    return mv;
}

// Rs (kOhm) of the element above the load resistor: Rs = RL * (Vcc - V) / V [SCH]
static float micsRs(float mv, float loadOhm)
{
    if (!(mv >= MICS_MIN_MV)) // also NAN
    {
        return NAN;
    }
    return fmaxf(0.0f, loadOhm * (MICS_VCC_MV - mv) / mv) / 1000.0f;
}

// The sensor task: preheat, then one reading per second; baseline when asked or after the warm-up.
static void micsTask(void *arg)
{
    (void)arg;
    const TickType_t start = xTaskGetTickCount();
    TickType_t wake = start;
    const uint32_t preheatS = MICS_PREHEAT_S; // a variable, so MICS_PREHEAT_S 0 compiles without a type-limits warning
    bool preheat = (preheatS > 0);
    gpio_set_level(MICS_PRE_IO, preheat);
    float r0[2] = {NAN, NAN};
    float sum[2] = {0.0f, 0.0f};
    int taken = -1; // readings in the baseline being taken; -1 = none being taken
    uint32_t seq = 0;
    for (;;)
    {
        const uint32_t elapsed = (xTaskGetTickCount() - start) / configTICK_RATE_HZ; // s
        if (preheat && elapsed >= preheatS)
        {
            gpio_set_level(MICS_PRE_IO, 0); // OX heater back to 43 mW
            preheat = false;
            ESP_LOGI(TAG_MICS, "OX preheat done");
        }

        micsReading_t r = {.seq = ++seq, .calibrated = (micsCali[0] != NULL && micsCali[1] != NULL)};
        for (int s = 0; s < 2; s++)
        {
            r.sensor[s].mv = micsReadMv(s, &r.sensor[s].over);
            r.sensor[s].rs = micsRs(r.sensor[s].mv, s == MICS_RED ? MICS_RED_LOAD_OHM : MICS_OX_LOAD_OHM);
        }

        // Baseline: when asked, or once the warm-up is over [DFR]; never during the preheat
        xSemaphoreTake(micsLock, portMAX_DELAY);
        const bool asked = micsBaselineAsked && !preheat;
        micsBaselineAsked = micsBaselineAsked && preheat; // a request during the preheat waits for its end
        xSemaphoreGive(micsLock);
        if (!preheat && (asked || (taken < 0 && isnan(r0[MICS_RED]) && elapsed >= MICS_WARMUP_S)))
        {
            taken = 0;
            sum[MICS_RED] = sum[MICS_OX] = 0.0f;
        }
        if (taken >= 0 && isfinite(r.sensor[MICS_RED].rs) && isfinite(r.sensor[MICS_OX].rs))
        {
            sum[MICS_RED] += r.sensor[MICS_RED].rs;
            sum[MICS_OX] += r.sensor[MICS_OX].rs;
            if (++taken == MICS_BASELINE_S)
            {
                r0[MICS_RED] = sum[MICS_RED] / (float)taken;
                r0[MICS_OX] = sum[MICS_OX] / (float)taken;
                taken = -1;
                ESP_LOGI(TAG_MICS, "Baseline R0: RED %.1f kOhm, OX %.2f kOhm", r0[MICS_RED], r0[MICS_OX]);
            }
        }

        r.sensor[MICS_RED].r0 = r0[MICS_RED];
        r.sensor[MICS_OX].r0 = r0[MICS_OX];
        if (preheat)
        {
            r.state = MICS_PREHEAT;
            r.secondsLeft = preheatS - elapsed;
        }
        else if (taken >= 0)
        {
            r.state = MICS_BASELINE;
            r.secondsLeft = MICS_BASELINE_S - taken;
        }
        else if (isnan(r0[MICS_RED]))
        {
            r.state = MICS_WARMUP;
            r.secondsLeft = (elapsed < MICS_WARMUP_S) ? MICS_WARMUP_S - elapsed : 0;
        }
        else
        {
            r.state = MICS_READY;
        }
        // ppm = (Rs/R0 / a)^(1/b) [FIT]; NAN when Rs or R0 is unknown
        for (size_t g = 0; g < MICS_GASES; g++)
        {
            const micsSensor_t *e = &r.sensor[micsGases[g].sensor];
            r.ppm[g] = powf(e->rs / e->r0 / micsGases[g].a, 1.0f / micsGases[g].b);
        }

        xSemaphoreTake(micsLock, portMAX_DELAY);
        micsPub = r;
        xSemaphoreGive(micsLock);

        if (seq % (MICS_LOG_EVERY_S * 1000 / MICS_PERIOD_MS) == 1)
        {
            ESP_LOGI(TAG_MICS, "%s | RED %.1f mV, Rs %.1f kOhm, R0 %.1f kOhm | OX %.1f mV, Rs %.2f kOhm, R0 %.2f kOhm",
                     micsStateName[r.state], r.sensor[MICS_RED].mv, r.sensor[MICS_RED].rs, r.sensor[MICS_RED].r0,
                     r.sensor[MICS_OX].mv, r.sensor[MICS_OX].rs, r.sensor[MICS_OX].r0);
        }
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(MICS_PERIOD_MS));
    }
}

// Sets up PRE_S (off), ADC1 and its calibration, then starts the task (which runs the preheat).
static inline esp_err_t mics4514Init(void)
{
    // 1. PRE_S output, low; the task switches the preheat on, so an init error leaves the OX heater at 43 mW
    const gpio_config_t pre = {.pin_bit_mask = 1ULL << MICS_PRE_IO, .mode = GPIO_MODE_OUTPUT};
    gpio_set_level(MICS_PRE_IO, 0);
    ESP_RETURN_ON_ERROR(gpio_config(&pre), TAG_MICS, "PRE_S pin");

    // 2. ADC1 channels from the schematic's GPIO numbers [ADC adc_oneshot.h L124], both at ATTEN3 to start
    adc_unit_t unit[2];
    ESP_RETURN_ON_ERROR(adc_oneshot_io_to_channel(MICS_RED_IO, &unit[MICS_RED], &micsChan[MICS_RED]), TAG_MICS, "VRED pin");
    ESP_RETURN_ON_ERROR(adc_oneshot_io_to_channel(MICS_OX_IO, &unit[MICS_OX], &micsChan[MICS_OX]), TAG_MICS, "VNOx pin");
    ESP_RETURN_ON_FALSE(unit[MICS_RED] == ADC_UNIT_1 && unit[MICS_OX] == ADC_UNIT_1, ESP_ERR_INVALID_ARG, TAG_MICS,
                        "both pins must be on ADC1");
    const adc_oneshot_unit_init_cfg_t unitCfg = {.unit_id = ADC_UNIT_1};
    ESP_RETURN_ON_ERROR(adc_oneshot_new_unit(&unitCfg, &micsAdc), TAG_MICS, "ADC1");
    const adc_oneshot_chan_cfg_t chanCfg = {.atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_12};
    for (int s = 0; s < 2; s++)
    {
        ESP_RETURN_ON_ERROR(adc_oneshot_config_channel(micsAdc, micsChan[s], &chanCfg), TAG_MICS, "ADC channel");
        micsAtten[s] = ADC_ATTEN_DB_12;
    }

    // 3. Calibration for the two attenuations used; ESP_ERR_NOT_SUPPORTED = no eFuse values, use nominal [ADC]
    const adc_atten_t attens[2] = {ADC_ATTEN_DB_0, ADC_ATTEN_DB_12};
    for (int i = 0; i < 2; i++)
    {
        const adc_cali_curve_fitting_config_t cfg = {
            .unit_id = ADC_UNIT_1, .chan = micsChan[MICS_RED], .atten = attens[i], .bitwidth = ADC_BITWIDTH_12};
        if (adc_cali_create_scheme_curve_fitting(&cfg, &micsCali[i]) != ESP_OK)
        {
            micsCali[i] = NULL;
            ESP_LOGW(TAG_MICS, "No ADC calibration for attenuation %d - voltages are nominal", (int)attens[i]);
        }
    }

    // 4. Lock, then the task
    micsLock = xSemaphoreCreateMutex();
    ESP_RETURN_ON_FALSE(micsLock != NULL, ESP_ERR_NO_MEM, TAG_MICS, "lock");
    ESP_RETURN_ON_FALSE(xTaskCreate(micsTask, "mics4514", MICS_TASK_STACK, NULL, MICS_TASK_PRIORITY, NULL) == pdPASS,
                        ESP_ERR_NO_MEM, TAG_MICS, "task");
    ESP_LOGI(TAG_MICS, "RED on IO%d, OX on IO%d; preheat %d s, clean-air baseline after %d s", MICS_RED_IO, MICS_OX_IO,
             MICS_PREHEAT_S, MICS_WARMUP_S);
    return ESP_OK;
}

// For other tasks: copies the latest reading. Returns false until the first reading exists.
static inline bool mics4514GetLatest(micsReading_t *out)
{
    if (micsLock == NULL || xSemaphoreTake(micsLock, pdMS_TO_TICKS(100)) != pdTRUE)
    {
        return false;
    }
    const bool ready = (micsPub.seq > 0);
    if (ready)
    {
        *out = micsPub;
    }
    xSemaphoreGive(micsLock);
    return ready;
}

// For other tasks: take a new clean-air baseline (starts at the next reading, or when the preheat ends).
static inline esp_err_t mics4514RequestBaseline(void)
{
    if (micsLock == NULL || xSemaphoreTake(micsLock, pdMS_TO_TICKS(100)) != pdTRUE)
    {
        return ESP_ERR_INVALID_STATE;
    }
    micsBaselineAsked = true;
    xSemaphoreGive(micsLock);
    return ESP_OK;
}

#endif // MICS4514_H

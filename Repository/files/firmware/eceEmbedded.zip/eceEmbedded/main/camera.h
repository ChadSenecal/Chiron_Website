#ifndef CAMERA_H
#define CAMERA_H
// =====================================================================================================
// camera.h - OV5640 on the Adafruit OV5640 Camera Breakout (120 deg, low distortion), on its own lines
//
// Bus:    SCCB (I2C) on cmrSCL / cmrSDA, I2C_NUM_1 - separate from the IR array bus
// Clock:  the breakout's own 24 MHz oscillator. Its XCLK jumper must be on INT (cut centre-EXT, bridge centre-INT);
//         FPC pin 8 (XC) is not connected on this board, so the ESP32 sends no clock [ADA].
// Image:  800 x 600 YUV422 (UYVY), PCLK 112 MHz / CAM_SYSCLK_DIV (camClockRegs), over the 8-bit DVP port, into two
//         buffers in PSRAM: cameraCapture() returns the frame it requested on the previous call and requests the next
//         one into the other buffer, so a frame is usually ready at once. Unrequested frames go to the driver's spare.
// Web:    cameraJpeg() compresses a snapshot (CAM_WEB_SCALE) to JPEG with Espressif's esp_new_jpeg [JPG].
// Needs:  menuconfig -> OV5640 driver enabled (its register tables are used; the format is picked here), PSRAM Octal.
// Load:   the driver's 800x600 UYVY register table is written here one register at a time instead of through
//         esp_cam_sensor_set_format(), which soft-resets the sensor and then waits one tick (0-10 ms at 100 Hz)
//         before the next write [SEN ov5640.c L27, ov5640_settings.h L79-84; OVDS].
// Health: VSYNC goes through the camera block's glitch filter [E32CAM]. A frame that ended early (VSYNC glitch) or lost
//         bytes (receive FIFO overflow [GDMAR]) is skipped and the next one is used; the log counts both.
// Boot:   HREF is on GPIO45, the VDD_SPI strapping pin (high at reset = 1.8 V flash supply) [S3DS]. The breakout holds
//         the camera powered and out of reset and clocks it itself [ADA], so it keeps streaming while the ESP32 resets.
//         Permanent fix: espefuse set-flash-voltage 3.3V (GPIO45 is then ignored) [EFUSE].
//
// References:
//  [ADA]   Adafruit, "Adafruit OV5640 Camera Breakouts" learn guide (pinouts, XCLK jumper, PD/RT pulls, I2C pull-ups)
//  [SEN]   Espressif esp_cam_sensor 2.6.0, sensors/ov5640/ov5640.c (github.com/espressif/esp-video-components)
//  [DVP]   ESP-IDF v6.1 esp_driver_cam: dvp/include/esp_cam_ctlr_dvp.h, dvp/src/esp_cam_ctlr_dvp_cam.c
//  [S3DS]  ESP32-S3 datasheet / hardware design guidelines: strapping pins, VDD_SPI voltage control
//  [EFUSE] esptool docs, ESP32-S3 espefuse "set-flash-voltage"
//  [OVDS]  OmniVision OV5640 datasheet section 2.7: >= 20 ms from RESETB high to stable SCCB, as applied in the
//          Linux ov5640 driver fix "media: ov5640: Fix power up sequence delays" (2022), which also drops the soft
//          reset when the RESET pin is used
//  [I2C]   ESP-IDF v6.1 esp_driver_i2c: i2c_master_bus_reset(); esp32s3 i2c_ll.h L34, L84 (hardware bus clear, 9 SCL)
//  [ESPFAQ] Espressif ESP-FAQ, Camera Application: "For ESP32-S3, the upper limit of PCLK is 40 MHz"
//  [LNX]   Linux drivers/media/i2c/ov5640.c clock tree (commit aa2882481cad): 0x3035 bits 7:4 = system clock divider,
//          shared by the sensor clock and PCLK
//  [JPG]   Espressif esp_new_jpeg 1.0.2, include/esp_jpeg_enc.h (CbYCrY = UYVY input since 1.0.0; on the ESP32-S3 the
//          input buffer must be 16-byte aligned) (github.com/espressif/esp-adf-libs, esp_new_jpeg)
//  [GDMAR] ESP-IDF v6.1 soc/esp32s3/register/soc/gdma_struct.h: in.peri_sel 5 = LCD_CAM; in.int_raw bit 6
//          infifo_ovf_l1, bit 8 infifo_ovf_l3 (sticky until written to in.int_clr)
//  [E32CAM] Espressif esp32-camera, target/esp32s3/ll_cam.c L333, L337, L348: VSYNC filter on, threshold 4 cycles of
//          the camera block clock (github.com/espressif/esp32-camera); ESP-IDF v6.1 turns it off (esp_hal_cam
//          cam_hal.c L82). Camera block clock source: PLL_D2 = 240 MHz (soc/esp32s3 clk_tree_defs.h L205-207).
// =====================================================================================================

#include "sdkconfig.h"
#if !CONFIG_CAMERA_OV5640
#error "Enable the OV5640 driver: idf.py menuconfig -> Component config -> Espressif Camera Sensors Configurations -> Camera Sensor Configuration -> Select and Set Camera Sensor -> OV5640"
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "esp_attr.h"
#include "esp_cam_ctlr.h"
#include "esp_cam_ctlr_dvp.h"
#include "esp_cam_sensor.h"
#include "esp_check.h"
#include "esp_heap_caps.h"
#include "esp_jpeg_enc.h"
#include "esp_log.h"
#include "esp_sccb_i2c.h"
#include "esp_sccb_intf.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "ov5640.h"
#include "soc/gdma_struct.h"
#include "soc/lcd_cam_struct.h"

// ---- Pins: schematic U5 (ESP32-S3-WROOM-1-N16R8) and FPC_Connector1 (the breakout's 2x9 header) ---------
#define CAM_SCCB_PORT I2C_NUM_1 // own bus (I2C_NUM_0 is the IR array)
#define CAM_SCCB_SCL_IO 2       // cmrSCL  FPC 3
#define CAM_SCCB_SDA_IO 3       // cmrSDA  FPC 4
#define CAM_VSYNC_IO 39         // cmrVS   FPC 5
#define CAM_HREF_IO 45          // cmrHS   FPC 6  (GPIO45 is also the flash-voltage strapping pin)
#define CAM_PCLK_IO 40          // cmrPC   FPC 7
#define CAM_RESET_IO 41         // cmrRT   FPC 17
#define CAM_PWDN_IO 21          // cmrPD   FPC 18
// 8-bit DVP data = sensor outputs D2..D9 = cmrD2..cmrD9 = FPC 16..9
#define CAM_DATA_IO {4, 5, 15, 16, 8, 48, 17, 18}

// ---- Settings ----------------------------------------------------------------------------------------
#define CAM_SCCB_SPEED_HZ 100000
#define CAM_XCLK_HZ 24000000         // the breakout's oscillator [ADA]; every OV5640 DVP format expects 24 MHz [SEN L105-161]
#define CAM_WEB_SCALE 2              // web snapshot = 800 x 600 / 2 = 400 x 300 (1 = full size, 4 = 200 x 150)
#define CAM_SYSCLK_DIV 6             // camera system clock divider (camClockRegs): PCLK = 112 MHz / div, fps = 28.6 / div
                                     // 4 = 28 MHz, 7.1 fps (the picture tore on the board); 6 = 18.7 MHz, 4.8 fps;
                                     // 8 = 14 MHz, 3.6 fps. 2 = 56 MHz is above the S3's 40 MHz limit [ESPFAQ].
#define CAM_FRAME_US (1896LL * 2 * 1034 * CAM_SYSCLK_DIV / 112) // one frame: 1896 x 2 bytes x 1034 lines at PCLK
                                     // 112 MHz / div (camClockRegs); 210 ms at div 6
#define CAM_CAPTURE_TIMEOUT_MS (CAM_FRAME_US * 5 / 1000) // 5 frames: waiting for a frame start, a skipped frame,
                                     // the frame the driver already gave its spare buffer, and the retake
#define CAM_VSYNC_FILTER 4           // VSYNC must hold for 4 camera-block clocks to count [E32CAM]
#define CAM_BLOCK_CLK_DIV 12         // camera block clock 240 MHz / 12 = 20 MHz, so the filter ignores pulses < 200 ns
#define CAM_JPEG_QUALITY 60          // 1-100 [JPG]; Espressif's speed figures use 60
#define CAM_WRITE_TRIES 3            // tries per register write; each retry follows a bus reset [I2C]
#define CAM_LOAD_ATTEMPTS 3          // whole-table loads; each retry follows a RESET pulse
#define CAM_RESET_SETTLE_MS 20       // RESETB high to stable SCCB [OVDS]
#define CAM_REG_END 0xFFFF           // end marker in the driver's register tables [SEN private_include/ov5640_regs.h]
#define CAM_REG_DELAY 0xFFFE         // "wait val ms" entry in the same tables [SEN]
#define CAM_DMA_PERIPH_LCDCAM 5      // GDMA peripheral number of LCD_CAM [GDMAR]
#define CAM_DMA_OVERFLOW ((1u << 6) | (1u << 8)) // infifo_ovf_l1, infifo_ovf_l3 [GDMAR]

static const char *TAG_CAM = "CAMERA";

static i2c_master_bus_handle_t camBus = NULL;
static esp_sccb_io_handle_t camSccb = NULL;
static esp_cam_sensor_device_t *camSensor = NULL;
static esp_cam_ctlr_handle_t camCtlr = NULL;
static uint8_t *camBuf[2] = {NULL, NULL}; // our two frame buffers, PSRAM; request n goes into camBuf[n & 1]
static size_t camFrameLen = 0;
static uint32_t camWidth = 0;
static uint32_t camHeight = 0;
static bool camReady = false;             // true once cameraInit() has completed every step
static volatile bool camWant = false;     // set by cameraCapture(): put the next frame into camBuf[camRequest & 1]
static volatile uint32_t camRequest = 0;  // number of the latest request
static volatile uint32_t camBufRequest[2] = {0, 0}; // request number each buffer was last handed to the DMA for
static volatile uint32_t camFinished = 0; // request number whose frame was completed last
static bool camOutstanding = false;       // camRequest is still expected to complete (false after a timeout)
static SemaphoreHandle_t camDone = NULL;
static int camDmaCh = -1;                 // GDMA Rx channel serving LCD_CAM (-1 = not found) [GDMAR]
static volatile uint32_t camBufStart[2];  // esp_timer time (us) when each buffer was handed to the DMA
static const uint32_t camMinFrameUs = (uint32_t)(CAM_FRAME_US * 9 / 10); // a frame shorter than this ended early
static volatile uint32_t camSkipShort = 0; // frames skipped because they ended early
static volatile uint32_t camSkipLost = 0;  // frames skipped because bytes were lost (FIFO overflow)
static uint32_t camSkipsLogged = 0;
static TickType_t camSkipLogTick = 0;
static jpeg_enc_handle_t camJpegEnc = NULL;
static uint8_t *camJpegBuf = NULL;        // JPEG output, PSRAM
static size_t camJpegMax = 0;
static uint8_t *camScaled = NULL;         // CAM_WEB_SCALE > 1: the scaled-down UYVY frame, PSRAM, 16-byte aligned [JPG]

// DVP driver callbacks, run in its interrupt [DVP esp_cam_ctlr_types.h]
// At each frame start: hand over the requested buffer once if a capture is waiting; otherwise the driver uses its
// spare buffer.
static bool IRAM_ATTR camOnGetNewTrans(esp_cam_ctlr_handle_t handle, esp_cam_ctlr_trans_t *trans, void *arg)
{
    (void)handle;
    (void)arg;
    if (camWant)
    {
        camWant = false;
        camBufRequest[camRequest & 1] = camRequest;
        camBufStart[camRequest & 1] = (uint32_t)esp_timer_get_time(); // IRAM function [esp_timer_impl_systimer.c L68, L75]
        if (camDmaCh >= 0)
        {
            GDMA.channel[camDmaCh].in.int_clr.val = CAM_DMA_OVERFLOW; // count only this frame's overflows [GDMAR]
        }
        trans->buffer = camBuf[camRequest & 1];
        trans->buflen = camFrameLen;
    }
    return false;
}

// At each frame end: only called for buffers we handed over (not the spare) [DVP esp_cam_ctlr_dvp_cam.c L302]. The
// driver asks for the next buffer before reporting this one [DVP L291-309], so the finished request is looked up per
// buffer rather than taken from the latest hand-over. A frame that ended early or lost bytes is not reported; its
// request is captured again from a later frame. A longer frame is kept: it can be legitimately long, and the DMA stops
// at the end of the buffer.
static bool IRAM_ATTR camOnTransFinished(esp_cam_ctlr_handle_t handle, esp_cam_ctlr_trans_t *trans, void *arg)
{
    (void)handle;
    (void)arg;
    BaseType_t woken = pdFALSE;
    for (int i = 0; i < 2; i++)
    {
        if (trans->buffer != camBuf[i])
        {
            continue;
        }
        const bool endedEarly = (uint32_t)esp_timer_get_time() - camBufStart[i] < camMinFrameUs;
        const bool lostBytes = camDmaCh >= 0 && (GDMA.channel[camDmaCh].in.int_raw.val & CAM_DMA_OVERFLOW) != 0;
        if (endedEarly || lostBytes)
        {
            camSkipShort += endedEarly;
            camSkipLost += !endedEarly;
            camWant = camWant || (camBufRequest[i] == camRequest); // retake a request that is still current
        }
        else
        {
            camFinished = camBufRequest[i];
            xSemaphoreGiveFromISR(camDone, &woken);
        }
    }
    return woken == pdTRUE;
}

// Waits at least ms: whole ticks rounded up, plus one because the first tick of vTaskDelay() can be partial.
static void camDelayMs(uint32_t ms)
{
    vTaskDelay((ms + portTICK_PERIOD_MS - 1) / portTICK_PERIOD_MS + 1);
}

// Pulses RESET (active low [ADA]); the pin was set up as an output by the driver's power-on [SEN ov5640_power_on].
// Then waits until SCCB is stable [OVDS].
static void camHardwareReset(void)
{
    gpio_set_level(CAM_RESET_IO, 0);
    camDelayMs(5);
    gpio_set_level(CAM_RESET_IO, 1);
    camDelayMs(CAM_RESET_SETTLE_MS);
}

// One register write (16-bit address, 8-bit value) [SEN ov5640_write]. A failed try resets the bus first: the I2C
// controller is reset and the hardware clocks SCL 9 times to free a held SDA [I2C]. If every try fails, the log shows
// both line levels (0 = held low), which tells a stuck bus from a sensor that stopped answering.
static esp_err_t camWriteReg(uint16_t reg, uint8_t val)
{
    esp_err_t err = ESP_FAIL;
    for (int tryNo = 1; tryNo <= CAM_WRITE_TRIES && err != ESP_OK; tryNo++)
    {
        if (tryNo > 1)
        {
            i2c_master_bus_reset(camBus);
            camDelayMs(1);
        }
        err = esp_sccb_transmit_reg_a16v8(camSccb, reg, val);
    }
    if (err != ESP_OK)
    {
        ESP_LOGE(TAG_CAM, "Register 0x%04X = 0x%02X failed %d times (%s); SCL (IO%d) = %d, SDA (IO%d) = %d", reg, val,
                 CAM_WRITE_TRIES, esp_err_to_name(err), CAM_SCCB_SCL_IO, gpio_get_level(CAM_SCCB_SCL_IO),
                 CAM_SCCB_SDA_IO, gpio_get_level(CAM_SCCB_SDA_IO));
    }
    return err;
}

// Writes a register table, honouring its delay entries, as the driver's ov5640_write_array() does [SEN].
static esp_err_t camWriteTable(const ov5640_reginfo_t *regs)
{
    for (size_t i = 0; regs[i].reg != CAM_REG_END; i++)
    {
        if (regs[i].reg == CAM_REG_DELAY)
        {
            camDelayMs(regs[i].val);
        }
        else
        {
            ESP_RETURN_ON_ERROR(camWriteReg(regs[i].reg, regs[i].val), TAG_CAM, "table entry %u", (unsigned)i);
        }
    }
    return ESP_OK;
}

// Written before the format table: system clock from the pad clock, then software power-down while loading. This is
// the driver's DVP reset table without its soft reset (0x3008 = 0x82) [SEN ov5640_settings.h L79-84]; the RESET pulse has
// already reset every register, so the soft reset is not needed [OVDS, Linux fix].
static const ov5640_reginfo_t camStartRegs[] = {
    {0x3103, 0x11},
    {0x3008, 0x42},
    {CAM_REG_END, 0x00},
};

// Written after the format table, which sets 0x3035 = 0x21 [SEN table L11]: system clock divider (bits 7:4) 2 ->
// CAM_SYSCLK_DIV. The table's clocks give PCLK = 24 MHz / 3 x 70 / div / 2 / 2.5 = 112 MHz / div (measured on the board:
// 56.1 MHz at 2, 27.9 MHz at 4). A frame is 1896 x 2 bytes x 1034 lines (the table's last writes, [SEN table
// L317-320]), so fps = PCLK / 3.92 M.
// This divider feeds every sensor clock, so the frame timing stays consistent [LNX].
static const ov5640_reginfo_t camClockRegs[] = {
    {0x3035, (CAM_SYSCLK_DIV << 4) | 0x01},
    {CAM_REG_END, 0x00},
};

// The driver's 800 x 600 YUV422 (UYVY) DVP format, including its register table [SEN ov5640_format_info_dvp].
static const esp_cam_sensor_format_t *camFindFormat(void)
{
    esp_cam_sensor_format_array_t formats = {0};
    if (esp_cam_sensor_query_format(camSensor, &formats) != ESP_OK)
    {
        return NULL;
    }
    for (uint32_t i = 0; i < formats.count; i++)
    {
        const esp_cam_sensor_format_t *f = &formats.format_array[i];
        if (f->port == ESP_CAM_SENSOR_DVP && f->format == ESP_CAM_SENSOR_PIXFORMAT_YUV422_UYVY && f->regs != NULL)
        {
            return f;
        }
    }
    return NULL;
}

static inline uint32_t cameraWebWidth(void)
{
    return camWidth / CAM_WEB_SCALE;
}

static inline uint32_t cameraWebHeight(void)
{
    return camHeight / CAM_WEB_SCALE;
}

// Scales a UYVY frame down by CAM_WEB_SCALE (nearest pixel). UYVY = U0 Y0 V0 Y1 for each pair of pixels, in arrival
// order on the 8-bit DVP port [DVP byte-order table]; an output pair takes U and V from its first pixel's pair.
static void camScale(const uint8_t *in, uint8_t *out)
{
    const uint32_t w = cameraWebWidth();
    for (uint32_t y = 0; y < cameraWebHeight(); y++)
    {
        const uint8_t *line = in + (size_t)y * CAM_WEB_SCALE * camWidth * 2;
        uint8_t *o = out + (size_t)y * w * 2;
        for (uint32_t x = 0; x < w; x += 2)
        {
            const uint32_t s0 = x * CAM_WEB_SCALE, s1 = (x + 1) * CAM_WEB_SCALE;
            const uint8_t *p0 = line + (s0 & ~1u) * 2, *p1 = line + (s1 & ~1u) * 2;
            o[2 * x + 0] = p0[0];
            o[2 * x + 1] = p0[1 + (s0 & 1u) * 2];
            o[2 * x + 2] = p0[2];
            o[2 * x + 3] = p1[1 + (s1 & 1u) * 2];
        }
    }
}

// Logs the skipped-frame counts (camOnTransFinished) when they change, at most every 5 s. "Ended early" means VSYNC
// glitches got through; "lost bytes" means the PSRAM could not keep up (raise CAM_SYSCLK_DIV to lower the PCLK).
static void camLogSkips(void)
{
    const uint32_t skipped = camSkipShort + camSkipLost;
    if (skipped != camSkipsLogged && xTaskGetTickCount() - camSkipLogTick >= pdMS_TO_TICKS(5000))
    {
        camSkipsLogged = skipped;
        camSkipLogTick = xTaskGetTickCount();
        ESP_LOGW(TAG_CAM, "Skipped %lu damaged frame(s) so far: %lu ended early, %lu lost bytes", (unsigned long)skipped,
                 (unsigned long)camSkipShort, (unsigned long)camSkipLost);
    }
}

static inline esp_err_t cameraCapture(const uint8_t **frame, uint32_t timeoutMs);

// Brings up SCCB, the sensor and the DVP receiver, and starts the sensor's output.
static inline esp_err_t cameraInit(void)
{
    // 1. SCCB bus on the camera's own lines; the breakout has its own SDA/SCL pull-ups [ADA]
    i2c_master_bus_handle_t bus = NULL;
    const i2c_master_bus_config_t busConfig = {
        .i2c_port = CAM_SCCB_PORT,
        .scl_io_num = CAM_SCCB_SCL_IO,
        .sda_io_num = CAM_SCCB_SDA_IO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = false,
    };
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&busConfig, &bus), TAG_CAM, "SCCB bus");
    esp_sccb_io_handle_t sccb = NULL;
    const sccb_i2c_config_t sccbConfig = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = OV5640_SCCB_ADDR, // 0x3C [SEN ov5640.h]
        .scl_speed_hz = CAM_SCCB_SPEED_HZ,
    };
    ESP_RETURN_ON_ERROR(sccb_new_i2c_io(bus, &sccbConfig, &sccb), TAG_CAM, "SCCB device");
    camBus = bus;
    camSccb = sccb;

    // 2. Sensor: the driver pulses PWDN and RESET, waits 20 ms after RESET [SEN ov5640_power_on,
    //    CONFIG_CAMERA_OV5640_POWER_ON_DELAY_US] and checks the chip ID
    esp_cam_sensor_config_t sensorConfig = {
        .sccb_handle = sccb,
        .reset_pin = CAM_RESET_IO,
        .pwdn_pin = CAM_PWDN_IO,
        .xclk_pin = -1, // no clock from the ESP32
        .xclk_freq_hz = CAM_XCLK_HZ,
        .sensor_port = ESP_CAM_SENSOR_DVP,
    };
    camSensor = ov5640_detect(&sensorConfig);
    if (camSensor == NULL)
    {
        ESP_LOGE(TAG_CAM, "No OV5640 answered at 0x%02X - is the breakout's XCLK jumper on INT?", OV5640_SCCB_ADDR);
        return ESP_ERR_NOT_FOUND;
    }

    // 3. Registers: the driver's own UYVY table, loaded here (see "Load" at the top) after a timed RESET pulse. A load
    //    that still fails after the per-register retries is repeated, again after a RESET pulse.
    const esp_cam_sensor_format_t *fmt = camFindFormat();
    if (fmt == NULL)
    {
        ESP_LOGE(TAG_CAM, "The OV5640 driver has no 8-bit DVP YUV422 (UYVY) format");
        return ESP_ERR_NOT_SUPPORTED;
    }
    esp_err_t err = ESP_FAIL;
    for (int attempt = 1; attempt <= CAM_LOAD_ATTEMPTS && err != ESP_OK; attempt++)
    {
        if (attempt > 1)
        {
            ESP_LOGW(TAG_CAM, "Register load failed - resetting the sensor, attempt %d of %d", attempt, CAM_LOAD_ATTEMPTS);
        }
        camHardwareReset(); // detect's own RESET pulse is one tick, 0-10 ms [SEN ov5640.c L27, L526-528]
        err = camWriteTable(camStartRegs);
        if (err == ESP_OK)
        {
            err = camWriteTable((const ov5640_reginfo_t *)fmt->regs);
        }
        if (err == ESP_OK)
        {
            err = camWriteTable(camClockRegs);
        }
    }
    ESP_RETURN_ON_ERROR(err, TAG_CAM, "register load");
    camWidth = fmt->width;
    camHeight = fmt->height;

    // 4. PSRAM: three frames of width x height x 2 bytes (our two + the driver's spare), the scaled frame and the JPEG
    //    output (at most 1 byte per pixel; quality 60 gives far less)
    const size_t frameBytes = (size_t)camWidth * camHeight * 2;
    const size_t webPixels = (size_t)cameraWebWidth() * cameraWebHeight();
    const size_t needBytes = 3 * frameBytes + (CAM_WEB_SCALE > 1 ? 2 * webPixels : 0) + webPixels;
    if (heap_caps_get_free_size(MALLOC_CAP_SPIRAM) < needBytes)
    {
        ESP_LOGE(TAG_CAM, "Needs %u KB of PSRAM - menuconfig: Component config -> ESP PSRAM -> Support for external, "
                          "SPI-connected RAM, and SPI RAM config -> Mode (QUAD/OCT) -> Octal Mode PSRAM",
                 (unsigned)(needBytes / 1024));
        return ESP_ERR_NO_MEM;
    }

    // 5. DVP receiver: 8-bit data, VSYNC, HREF (data enable), PCLK; external_xtal = no clock output [DVP]
    const esp_cam_ctlr_dvp_pin_config_t pins = {
        .data_width = CAM_CTLR_DATA_WIDTH_8,
        .data_io = CAM_DATA_IO,
        .vsync_io = CAM_VSYNC_IO,
        .de_io = CAM_HREF_IO,
        .pclk_io = CAM_PCLK_IO,
        .xclk_io = GPIO_NUM_NC,
    };
    const esp_cam_ctlr_dvp_config_t dvpConfig = {
        .ctlr_id = 0,
        .clk_src = CAM_CLK_SRC_DEFAULT,
        .h_res = camWidth,
        .v_res = camHeight,
        .input_data_color_type = CAM_CTLR_COLOR_YUV422_UYVY,
        .output_data_color_type = CAM_CTLR_COLOR_YUV422_UYVY, // no conversion: bytes stored as they arrive
        .cam_data_width = 8,
        // GDMA Rx block size into PSRAM. The S3 documents 16 or 32 bytes ("2/3: reserved") [gdma_reg.h L50-52]; 64 is
        // written as code 2 [gdma_ll.h L61, L205-206], and on the board the DMA then wrote 32 bytes and stopped.
        .dma_burst_size = 32,
        .external_xtal = 1,
        .pin = &pins,
    };
    ESP_RETURN_ON_ERROR(esp_cam_new_dvp_ctlr(&dvpConfig, &camCtlr), TAG_CAM, "DVP controller");
    ESP_RETURN_ON_ERROR(esp_cam_ctlr_get_frame_buffer_len(camCtlr, &camFrameLen), TAG_CAM, "frame size");
    camBuf[0] = esp_cam_ctlr_alloc_buffer(camCtlr, camFrameLen, MALLOC_CAP_SPIRAM); // DMA-aligned [DVP], so also the
    camBuf[1] = esp_cam_ctlr_alloc_buffer(camCtlr, camFrameLen, MALLOC_CAP_SPIRAM); // 16 bytes the encoder needs [JPG]
    camDone = xSemaphoreCreateBinary();
    if (camBuf[0] == NULL || camBuf[1] == NULL || camDone == NULL)
    {
        return ESP_ERR_NO_MEM;
    }
    const esp_cam_ctlr_evt_cbs_t callbacks = {
        .on_get_new_trans = camOnGetNewTrans,
        .on_trans_finished = camOnTransFinished,
    };
    ESP_RETURN_ON_ERROR(esp_cam_ctlr_register_event_callbacks(camCtlr, &callbacks, NULL), TAG_CAM, "callbacks");
    // VSYNC glitch filter, as esp32-camera sets it for the S3 [E32CAM]; the driver created the receiver with it off.
    // Takes effect at the register update in esp_cam_ctlr_enable() [cam_ll.h cam_ll_start: cam_update].
    LCD_CAM.cam_ctrl.cam_clkm_div_num = CAM_BLOCK_CLK_DIV;
    LCD_CAM.cam_ctrl.cam_clkm_div_a = 0;
    LCD_CAM.cam_ctrl.cam_clkm_div_b = 0;
    LCD_CAM.cam_ctrl.cam_vsync_filter_thres = CAM_VSYNC_FILTER;
    LCD_CAM.cam_ctrl1.cam_vsync_filter_en = 1;
    ESP_RETURN_ON_ERROR(esp_cam_ctlr_enable(camCtlr), TAG_CAM, "enable");
    ESP_RETURN_ON_ERROR(esp_cam_ctlr_start(camCtlr), TAG_CAM, "start");
    for (int ch = 0; ch < 5 && camDmaCh < 0; ch++)
    {
        camDmaCh = (GDMA.channel[ch].in.peri_sel.sel == CAM_DMA_PERIPH_LCDCAM) ? ch : -1; // the driver's channel [GDMAR]
    }
    if (camDmaCh >= 0)
    {
        GDMA.channel[camDmaCh].in.int_clr.val = CAM_DMA_OVERFLOW;
    }

    // 6. JPEG encoder for the web snapshots: UYVY (CbYCrY) in, 4:2:0 out [JPG]
    jpeg_enc_config_t jpegConfig = DEFAULT_JPEG_ENC_CONFIG();
    jpegConfig.width = (int)cameraWebWidth();
    jpegConfig.height = (int)cameraWebHeight();
    jpegConfig.src_type = JPEG_PIXEL_FORMAT_CbYCrY;
    jpegConfig.subsampling = JPEG_SUBSAMPLE_420;
    jpegConfig.quality = CAM_JPEG_QUALITY;
    if (jpeg_enc_open(&jpegConfig, &camJpegEnc) != JPEG_ERR_OK)
    {
        ESP_LOGE(TAG_CAM, "JPEG encoder did not start");
        return ESP_FAIL;
    }
    camJpegMax = webPixels;
    camJpegBuf = heap_caps_malloc(camJpegMax, MALLOC_CAP_SPIRAM);
    camScaled = (CAM_WEB_SCALE > 1) ? heap_caps_aligned_alloc(16, 2 * webPixels, MALLOC_CAP_SPIRAM) : NULL;
    if (camJpegBuf == NULL || (CAM_WEB_SCALE > 1 && camScaled == NULL))
    {
        return ESP_ERR_NO_MEM;
    }

    // 7. Sensor output on: leave software power-down, as the driver's stream-on does [SEN ov5640_set_stream_dvp]
    ESP_RETURN_ON_ERROR(camWriteReg(0x3008, 0x02), TAG_CAM, "stream on");
    camReady = true;
    ESP_LOGI(TAG_CAM, "OV5640 streaming %s, system clock / %d: PCLK %lu kHz, ~%lu.%lu fps; web snapshots %lux%lu",
             fmt->name, CAM_SYSCLK_DIV, (unsigned long)(112000 / CAM_SYSCLK_DIV),
             (unsigned long)(286 / CAM_SYSCLK_DIV / 10), (unsigned long)(286 / CAM_SYSCLK_DIV % 10),
             (unsigned long)(camWidth / CAM_WEB_SCALE), (unsigned long)(camHeight / CAM_WEB_SCALE));

    // 8. First frame. If none arrives with the VSYNC filter on, run without it (as before the filter) and say so.
    //    This also leaves the next frame on its way for the first web request (cameraCapture).
    const uint8_t *frame = NULL;
    if (cameraCapture(&frame, CAM_CAPTURE_TIMEOUT_MS) != ESP_OK)
    {
        ESP_LOGW(TAG_CAM, "No frame with the VSYNC filter on - turning the filter off");
        LCD_CAM.cam_ctrl1.cam_vsync_filter_en = 0;
        LCD_CAM.cam_ctrl.cam_update = 1; // applies the change [cam_ll.h cam_ll_start]
    }
    return ESP_OK;
}

// Returns a complete frame (camWidth x camHeight, UYVY) and requests the next one into the other buffer, so the next
// call usually returns at once. The frame stays unchanged until the next call. Call from one task at a time.
// Request numbers make a completion left over from an earlier, timed-out request count as nothing.
static inline esp_err_t cameraCapture(const uint8_t **frame, uint32_t timeoutMs)
{
    if (!camReady)
    {
        return ESP_ERR_INVALID_STATE; // cameraInit() failed or was not called
    }
    if (!camOutstanding)
    {
        camRequest = camRequest + 1;
        camOutstanding = true;
        camWant = true;
    }
    const uint32_t request = camRequest;
    const TickType_t start = xTaskGetTickCount();
    while (camFinished != request)
    {
        const TickType_t waited = xTaskGetTickCount() - start;
        if (waited >= pdMS_TO_TICKS(timeoutMs) || xSemaphoreTake(camDone, pdMS_TO_TICKS(timeoutMs) - waited) != pdTRUE)
        {
            camWant = false;
            camOutstanding = false;
            ESP_LOGW(TAG_CAM, "No frame within %lu ms - check PCLK (IO%d), VSYNC (IO%d) and HREF (IO%d)",
                     (unsigned long)timeoutMs, CAM_PCLK_IO, CAM_VSYNC_IO, CAM_HREF_IO);
            return ESP_ERR_TIMEOUT;
        }
    }
    camLogSkips();
    camRequest = request + 1; // the next frame goes into the other buffer
    camWant = true;
    *frame = camBuf[request & 1];
    return ESP_OK;
}

// A snapshot of cameraWebWidth() x cameraWebHeight() as JPEG [JPG]. The JPEG stays unchanged until the next call.
// Call from one task at a time.
static inline esp_err_t cameraJpeg(const uint8_t **jpg, size_t *len, uint32_t timeoutMs)
{
    const uint8_t *frame = NULL;
    const esp_err_t err = cameraCapture(&frame, timeoutMs);
    if (err != ESP_OK)
    {
        return err;
    }
    if (CAM_WEB_SCALE > 1)
    {
        camScale(frame, camScaled);
        frame = camScaled;
    }
    int out = 0;
    const jpeg_error_t jerr = jpeg_enc_process(camJpegEnc, frame, (int)(2 * cameraWebWidth() * cameraWebHeight()),
                                               camJpegBuf, (int)camJpegMax, &out);
    if (jerr != JPEG_ERR_OK)
    {
        ESP_LOGE(TAG_CAM, "JPEG encoding failed (%d)", (int)jerr);
        return ESP_FAIL;
    }
    *jpg = camJpegBuf;
    *len = (size_t)out;
    return ESP_OK;
}

#endif // CAMERA_H

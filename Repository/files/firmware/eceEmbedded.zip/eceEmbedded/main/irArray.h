#ifndef IR_ARRAY_H
#define IR_ARRAY_H
// =====================================================================================================
// irArray.h - Melexis MLX90640ESF-BAA thermal IR array (32 x 24 pixels, 110 x 75 deg field of view)
//
// Does:  find the sensor, set its refresh rate, load its factory calibration, receive every subpage,
//        convert it to temperatures (C) with Melexis' library, and publish the latest full image for
//        other tasks (irArrayGetLatest(), used by webServer.h).
// Uses:  Melexis' MLX90640 library, unmodified, in components/mlx90640. This file supplies the I2C driver
//        functions that library calls by name (MLX90640_I2CRead, ...), so include it in ONE .c file only.
//
// References used in the comments below:
//  [DS]     Melexis, MLX90640 32x24 IR array datasheet, Rev. 13 (21 Oct 2026)
//           https://media.melexis.com/-/media/files/documents/datasheets/MLX90640-datasheet-melexis.pdf
//  [API]    Melexis mlx90640-library, functions/MLX90640_API.c @ f6be7ca (Apache-2.0)
//           https://github.com/melexis/mlx90640-library
//  [I2CDRV] Same repository, Melexis' original I2C driver functions/MLX90640_I2C_Driver.cpp @ 8fe3383
//  [DRVDOC] Same repository, "MLX90640 driver.pdf" (Melexis, Driver Rev. 1, 31 Oct 2022)
//  [IDF]    ESP-IDF v6.1 (components/esp_driver_i2c, docs/en/api-reference/system/freertos_idf.rst)
// =====================================================================================================

#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "driver/i2c_master.h"
#include "esp_check.h"
#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "MLX90640_API.h"
#include "MLX90640_I2C_Driver.h"

// ---- Bus ------------------------------------------------------------------------------------------
#define IR_I2C_ADDR 0x33       // default slave address [DS Table 5]
#define IR_I2C_SPEED_HZ 400000 // sensor allows up to 1 MHz [DS 10.2], EEPROM access max 400 kHz [DS Table 5 note 5]
#define IR_I2C_TIMEOUT_MS 100  // per transaction; -1 would wait forever [IDF i2c_master.h]
#define IR_POR_DELAY_MS 80     // wait after power-on before the first access [DS Fig. 7]
#define IR_POLL_MS 10          // status poll interval = 1 tick at the default 100 Hz FreeRTOS tick

// ---- Measurement settings -------------------------------------------------------------------------
#define IR_REFRESH_RATE_CODE 3 // control register bits 9:7 [DS Fig. 12]: 3 = 4 Hz per subpage = 2 full images/s.
                               // -1 = keep the sensor's own setting (factory 2 Hz) and write nothing
#define IR_EMISSIVITY 0.95f    // object emissivity used in Melexis' examples [DRVDOC 3.4.3]
#define IR_TA_SHIFT 8.0f       // reflected temperature = sensor temperature - 8 C, Melexis' open-air default [DRVDOC 3.4.3 ex. 2]
#define IR_TASK_STACK 8192     // bytes [IDF freertos_idf.rst]; ExtractParameters() keeps three float[768] arrays
                               // on the stack [API L881, L1047, L1122], more than the 3584 B main task has
#define IR_TASK_PRIORITY 5
#define IR_TASK_CORE 1         // Wi-Fi runs on core 0 by default [IDF esp_wifi Kconfig ESP_WIFI_TASK_CORE_ID]
#define IR_LOG_EVERY_MS 2000   // temperature summary in the serial log

// ---- Memory map [DS Fig. 10, Fig. 14] ---------------------------------------------------------------
#define IR_REG_STATUS 0x8000    // status register [DS Fig. 11]
#define IR_REG_CTRL1 0x800D     // control register 1 [DS Fig. 12]
#define IR_RAM_START 0x0400     // 768 pixel words (0x0400-0x06FF), then 64 aux words (0x0700-0x073F)
#define IR_EEPROM_START 0x2400  // 832 words of factory calibration, 0x2400-0x273F [DRVDOC 2.1.3]
#define IR_PIXELS 768           // 32 columns x 24 rows
#define IR_COLS 32
#define IR_ROWS 24
#define IR_RAM_WORDS 832        // 768 + 64 (the EEPROM is also 832 words)
#define IR_FRAME_CTRL 832       // frameData[832] = control register 1 } same layout as [API] MLX90640_GetFrameData(),
#define IR_FRAME_SUBPAGE 833    // frameData[833] = subpage (0 or 1)   } which Melexis' CalculateTo() expects
#define IR_FRAME_WORDS 834

// ---- Status register 0x8000 [DS Fig. 11] -------------------------------------------------------------
#define IR_STATUS_SUBPAGE 0x0001  // bit 0: subpage just measured ([API] MLX90640_STAT_FRAME_MASK)
#define IR_STATUS_NEW_DATA 0x0008 // bit 3: new subpage in RAM, must be reset by the host [DS 10.4]
#define IR_STATUS_CLEAR 0x0030    // value Melexis writes to reset bit 3 ([API] MLX90640_INIT_STATUS_VALUE):
                                  // bit 3 = 0, bit 4 = 1 (RAM overwrite enabled), bit 5 = 1 (step mode only [DS Fig. 7])
#define IR_NOT_MEASURED 0x7FFF    // RAM word not measured yet ([API] ValidateFrameData / ValidateAuxData)

// ---- Control register 1 fields [DS Fig. 12]; factory value 0x1901 [DS Table 8] -------------------------
#define IR_CTRL_SUBPAGE_MODE(c) ((c) & 0x1)       // bit 0: 1 = two subpages (default)
#define IR_CTRL_RATE(c) (((c) >> 7) & 0x7)        // bits 9:7: refresh rate = 0.5 Hz x 2^n (default n = 2, 2 Hz)
#define IR_CTRL_RESOLUTION(c) (((c) >> 10) & 0x3) // bits 11:10: ADC resolution = 16 + n bits (default 18-bit)
#define IR_CTRL_CHESS(c) (((c) >> 12) & 0x1)      // bit 12: 1 = chess pattern (default), 0 = interleaved

static const char *TAG_IR = "IR ARRAY";

static i2c_master_dev_handle_t irDev = NULL; // the sensor on the shared bus
static uint32_t irSubpageMs = 500;           // subpage period, set in irArrayInit()
static TickType_t irLastNewData = 0;         // when the last subpage was seen
static bool irStarted = false;
static uint8_t irRxBuf[IR_RAM_WORDS * 2]; // static: 1664 B is too much for the 3584 B main task stack (ESP-IDF default)

static uint16_t irEeprom[IR_RAM_WORDS]; // raw EEPROM image, only needed until the parameters are extracted
static paramsMLX90640 irParams;         // calibration parameters extracted from the EEPROM (~5 KB)
static float irTo[IR_PIXELS];           // working image in C; CalculateTo() updates the half just measured

static SemaphoreHandle_t irLock = NULL; // guards the published copy below (read by the web server task)
static float irPubTo[IR_PIXELS];
static float irPubTa = 0.0f;
static uint32_t irPubSeq = 0; // counts published images; 0 = none yet

// Reads n 16-bit words from addr. Bus sequence [DS Fig. 5]: START, 0x33+W, addr MSB, addr LSB,
// repeated START, 0x33+R, data MSB, data LSB, ..., STOP. i2c_master_transmit_receive() sends exactly this
// [IDF i2c_master.c L1326-1333]. The sensor auto-increments the address within one read [DRVDOC 2.1.3], and the
// driver splits long reads into FIFO-sized pieces itself [IDF i2c_master.c L288], so 832 words fit one call.
static esp_err_t irArrayRead(uint16_t addr, uint16_t *data, size_t n)
{
    if (n == 0 || n > IR_RAM_WORDS)
    {
        return ESP_ERR_INVALID_SIZE;
    }

    const uint8_t cmd[2] = {(uint8_t)(addr >> 8), (uint8_t)(addr & 0xFF)}; // address MSB first [I2CDRV]
    esp_err_t err = i2c_master_transmit_receive(irDev, cmd, sizeof(cmd), irRxBuf, n * 2, IR_I2C_TIMEOUT_MS);
    if (err != ESP_OK)
    {
        ESP_LOGE(TAG_IR, "Read of %u word(s) at 0x%04X failed: %s", (unsigned)n, addr, esp_err_to_name(err));
        return err;
    }

    for (size_t i = 0; i < n; i++)
    {
        data[i] = (uint16_t)((irRxBuf[2 * i] << 8) | irRxBuf[2 * i + 1]); // each word arrives MSB first [I2CDRV]
    }
    return ESP_OK;
}

// Resets the new-data flag: writes 0x0030 to 0x8000. Bus sequence [DS Fig. 4]: START, 0x33+W, addr MSB, addr LSB,
// data MSB, data LSB, STOP [I2CDRV]. No read-back: bits 0-2 are read-only and bit 3 can already be set again;
// [API] L134-138 also accepts this write without its read-back check.
static esp_err_t irArrayClearNewData(void)
{
    const uint8_t cmd[4] = {IR_REG_STATUS >> 8, IR_REG_STATUS & 0xFF, IR_STATUS_CLEAR >> 8, IR_STATUS_CLEAR & 0xFF};
    esp_err_t err = i2c_master_transmit(irDev, cmd, sizeof(cmd), IR_I2C_TIMEOUT_MS);
    if (err != ESP_OK)
    {
        ESP_LOGE(TAG_IR, "Write to 0x%04X failed: %s", IR_REG_STATUS, esp_err_to_name(err));
    }
    return err;
}

// ---- I2C driver functions for Melexis' library [DRVDOC 2.1]. The library calls them by name, so they are not
// static. slaveAddr is ignored: irDev is already bound to 0x33 (one sensor on this bus).
void MLX90640_I2CInit(void) {} // the bus is created in main.c

void MLX90640_I2CFreqSet(int freq) // the speed is fixed per device (IR_I2C_SPEED_HZ)
{
    (void)freq;
}

// 0 = OK, -1 = NACK/bus error [DRVDOC 2.1.3]
int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data)
{
    (void)slaveAddr;
    return (irArrayRead(startAddress, data, nMemAddressRead) == ESP_OK) ? 0 : -1;
}

// Writes one word and reads it back: 0 = OK, -1 = NACK/bus error, -2 = read-back differs [DRVDOC 2.1.4], the same
// checks as Melexis' own driver [I2CDRV]. The calibration EEPROM is refused: it cannot be restored if overwritten.
int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data)
{
    (void)slaveAddr;
    if (writeAddress >= IR_EEPROM_START && writeAddress < IR_EEPROM_START + IR_RAM_WORDS)
    {
        ESP_LOGE(TAG_IR, "Refusing to write EEPROM address 0x%04X", writeAddress);
        return -1;
    }
    const uint8_t cmd[4] = {(uint8_t)(writeAddress >> 8), (uint8_t)(writeAddress & 0xFF), (uint8_t)(data >> 8), (uint8_t)(data & 0xFF)};
    if (i2c_master_transmit(irDev, cmd, sizeof(cmd), IR_I2C_TIMEOUT_MS) != ESP_OK)
    {
        return -1;
    }
    uint16_t check = 0;
    if (irArrayRead(writeAddress, &check, 1) != ESP_OK)
    {
        return -1;
    }
    return (check == data) ? 0 : -2;
}

// Only used by MLX90640_TriggerMeasurement() (step mode, not used here). Not implemented: the I2C general-call
// reset it needs would reset every device on the shared bus [DRVDOC 2.1.5].
int MLX90640_I2CGeneralReset(void)
{
    return -1;
}

// Melexis' checks ([API] ValidateAuxData L193-230, ValidateFrameData L180-191): RAM reads 0x7FFF until the sensor has
// measured it, e.g. after power-up [DS 12.2.1]. Melexis only skips copying bad aux data; here it rejects the subpage.
static bool irArrayFrameValid(const uint16_t *frameData)
{
    static const uint8_t auxChecked[][2] = {{0, 1}, {8, 19}, {20, 23}, {24, 33}, {40, 51}, {52, 55}, {56, 64}};
    const uint16_t *aux = &frameData[IR_PIXELS];

    for (size_t r = 0; r < sizeof(auxChecked) / sizeof(auxChecked[0]); r++)
    {
        for (unsigned i = auxChecked[r][0]; i < auxChecked[r][1]; i++)
        {
            if (aux[i] == IR_NOT_MEASURED)
            {
                return false;
            }
        }
    }

    // First pixel of each row that belongs to this subpage
    for (unsigned row = 0; row < IR_ROWS; row++)
    {
        if ((row % 2u) == frameData[IR_FRAME_SUBPAGE] && frameData[row * IR_COLS] == IR_NOT_MEASURED)
        {
            return false;
        }
    }
    return true;
}

// Adds the sensor to the shared bus, waits out power-up, checks that it answers, sets the refresh rate and
// reads the configuration back.
static inline esp_err_t irArrayInit(i2c_master_bus_handle_t bus)
{
    const i2c_device_config_t devConfig = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7, // [IDF i2c_master.h L48-50]
        .device_address = IR_I2C_ADDR,
        .scl_speed_hz = IR_I2C_SPEED_HZ,
    };
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(bus, &devConfig, &irDev), TAG_IR, "could not add the sensor to the bus");

    vTaskDelay(pdMS_TO_TICKS(IR_POR_DELAY_MS)); // [DS Fig. 7]

    // ACK = present, NACK = ESP_ERR_NOT_FOUND, ESP_ERR_TIMEOUT = check the pull-ups [IDF i2c_master.h L236-260]
    esp_err_t err = i2c_master_probe(bus, IR_I2C_ADDR, IR_I2C_TIMEOUT_MS);
    if (err != ESP_OK)
    {
        ESP_LOGE(TAG_IR, "No answer at 0x%02X: %s", IR_I2C_ADDR, esp_err_to_name(err));
        return err;
    }

#if IR_REFRESH_RATE_CODE >= 0
    // Read-modify-write of bits 9:7 only, verified by read-back [API MLX90640_SetRefreshRate, DRVDOC 2.1.4].
    // Register only: lost at power-off, the EEPROM is not touched. Takes effect after the current subpage [DS 12.2.1].
    if (MLX90640_SetRefreshRate(IR_I2C_ADDR, IR_REFRESH_RATE_CODE) != 0)
    {
        ESP_LOGW(TAG_IR, "Could not set the refresh rate - keeping the sensor's own setting");
    }
#endif

    // Control register 1 (power-up value comes from EEPROM 0x240C [DS Table 8])
    uint16_t ctrl = 0;
    ESP_RETURN_ON_ERROR(irArrayRead(IR_REG_CTRL1, &ctrl, 1), TAG_IR, "control register read failed");
    irSubpageMs = 2000u >> IR_CTRL_RATE(ctrl); // one subpage per refresh period ([DS Fig. 6]: 4 Hz -> 250 ms)
    irStarted = false;

    static const char *const rateHz[8] = {"0.5", "1", "2", "4", "8", "16", "32", "64"};
    ESP_LOGI(TAG_IR, "MLX90640 at 0x%02X, control register 0x%04X: %s Hz (%u ms per subpage), %u-bit ADC, %s pattern, subpage mode %s",
             IR_I2C_ADDR, ctrl, rateHz[IR_CTRL_RATE(ctrl)], (unsigned)irSubpageMs, 16u + IR_CTRL_RESOLUTION(ctrl),
             IR_CTRL_CHESS(ctrl) ? "chess" : "interleaved", IR_CTRL_SUBPAGE_MODE(ctrl) ? "on" : "off");
    return ESP_OK;
}

// Receives the next subpage into frameData (IR_FRAME_WORDS words): [0..767] pixels, [768..831] aux,
// [832] control register 1, [833] subpage. Sequence of [API] MLX90640_GetFrameData() L114-178, timing of [DS Fig. 7].
// Returns ESP_OK, ESP_ERR_TIMEOUT (no new subpage), ESP_ERR_NOT_FINISHED (RAM not measured yet) or the I2C error.
static inline esp_err_t irArrayGetFrameData(uint16_t *frameData)
{
    // 1. After a subpage, wait ~80% of the refresh period before polling again [DS Fig. 7]
    if (irStarted)
    {
        const TickType_t quiet = pdMS_TO_TICKS(irSubpageMs * 8 / 10);
        const TickType_t elapsed = xTaskGetTickCount() - irLastNewData;
        if (elapsed < quiet)
        {
            vTaskDelay(quiet - elapsed);
        }
    }

    // 2. Poll status bit 3, new data available in RAM [DS Fig. 11]; [API] L123-132 polls the same bit
    uint16_t status = 0;
    const uint32_t timeoutMs = 2 * irSubpageMs + 100;
    const TickType_t start = xTaskGetTickCount();
    for (;;)
    {
        ESP_RETURN_ON_ERROR(irArrayRead(IR_REG_STATUS, &status, 1), TAG_IR, "status read failed");
        if (status & IR_STATUS_NEW_DATA)
        {
            break;
        }
        if ((xTaskGetTickCount() - start) > pdMS_TO_TICKS(timeoutMs))
        {
            ESP_LOGE(TAG_IR, "No new subpage within %u ms (status 0x%04X)", (unsigned)timeoutMs, status);
            return ESP_ERR_TIMEOUT;
        }
        vTaskDelay(pdMS_TO_TICKS(IR_POLL_MS));
    }
    irLastNewData = xTaskGetTickCount();
    irStarted = true;

    // 3. Reset the flag before reading, as [API] L134 does: a subpage that ends during the read sets it again
    ESP_RETURN_ON_ERROR(irArrayClearNewData(), TAG_IR, "clearing the new-data flag failed");

    // 4. All of RAM in one read [DRVDOC 2.1.3, example 2]; [API] L140 and L146 read pixels and aux separately
    ESP_RETURN_ON_ERROR(irArrayRead(IR_RAM_START, frameData, IR_RAM_WORDS), TAG_IR, "RAM read failed");

    // 5. Melexis frame layout [API] L152-155
    ESP_RETURN_ON_ERROR(irArrayRead(IR_REG_CTRL1, &frameData[IR_FRAME_CTRL], 1), TAG_IR, "control register read failed");
    frameData[IR_FRAME_SUBPAGE] = status & IR_STATUS_SUBPAGE;

    // 6. Reject RAM that has not been measured yet
    if (!irArrayFrameValid(frameData))
    {
        ESP_LOGW(TAG_IR, "Subpage %u still holds 0x7FFF (not measured) - skipped", (unsigned)frameData[IR_FRAME_SUBPAGE]);
        return ESP_ERR_NOT_FINISHED;
    }
    return ESP_OK;
}

// Reads the 832-word calibration EEPROM and converts it into irParams [DRVDOC 3.2.2] (read at 400 kHz, the EEPROM
// limit [DS Table 5 note 5]).
// Two checks run BEFORE Melexis' code sees the data: ExtractParameters() never returns on a blank image, because its
// Kta and Kv scaling loops double 0 until it reaches 63.4 [API L1086, L1177]. A blank or garbled read fails both:
//  - EEPROM 0x240F holds the sensor's I2C address in its low byte (0x33)
//  - at most 4 pixel words may be 0x0000 (broken), the same limit Melexis applies [API ExtractDeviatingPixels]
// ExtractParameters() itself then rejects more than 4 broken/outlier pixels, or two that touch.
static esp_err_t irArrayLoadCalibration(void)
{
    if (MLX90640_DumpEE(IR_I2C_ADDR, irEeprom) != 0)
    {
        ESP_LOGE(TAG_IR, "Calibration EEPROM read failed");
        return ESP_FAIL;
    }

    int zeroPixels = 0;
    for (unsigned p = 0; p < IR_PIXELS; p++)
    {
        zeroPixels += (irEeprom[64 + p] == 0x0000);
    }
    if ((irEeprom[0x0F] & 0x00FF) != IR_I2C_ADDR || zeroPixels > 4)
    {
        ESP_LOGE(TAG_IR, "EEPROM does not look like calibration data (0x240F = 0x%04X, %d blank pixel words)", irEeprom[0x0F], zeroPixels);
        return ESP_ERR_INVALID_RESPONSE;
    }

    const int rc = MLX90640_ExtractParameters(irEeprom, &irParams);
    if (rc != 0)
    {
        ESP_LOGE(TAG_IR, "Calibration EEPROM rejected by MLX90640_ExtractParameters (error %d)", rc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    int broken = 0;
    int outliers = 0;
    while (broken < 5 && irParams.brokenPixels[broken] != 0xFFFF) // lists end with 0xFFFF [DRVDOC 3.5.1]
    {
        broken++;
    }
    while (outliers < 5 && irParams.outlierPixels[outliers] != 0xFFFF)
    {
        outliers++;
    }
    ESP_LOGI(TAG_IR, "Calibration loaded: %d broken and %d outlier pixel(s) will be filled in from neighbours", broken, outliers);
    return ESP_OK;
}

// Converts one subpage to temperatures [DRVDOC 3.4.2, 3.4.3, 3.5.1]. CalculateTo() only writes the pixels measured in
// this subpage [API L477], so irTo holds a full image once both subpages have been converted. Returns the sensor's
// own (die) temperature.
static float irArrayConvert(uint16_t *frameData)
{
    const float ta = MLX90640_GetTa(frameData, &irParams);
    MLX90640_CalculateTo(frameData, &irParams, IR_EMISSIVITY, ta - IR_TA_SHIFT, irTo);

    const int mode = IR_CTRL_CHESS(frameData[IR_FRAME_CTRL]); // 1 = chess, 0 = interleaved [DRVDOC 3.5.1]
    MLX90640_BadPixelsCorrection(irParams.brokenPixels, irTo, mode, &irParams);
    MLX90640_BadPixelsCorrection(irParams.outlierPixels, irTo, mode, &irParams);
    return ta;
}

// Copies the working image into the published copy, under the lock.
static void irArrayPublish(float ta)
{
    xSemaphoreTake(irLock, portMAX_DELAY);
    memcpy(irPubTo, irTo, sizeof(irPubTo));
    irPubTa = ta;
    irPubSeq++;
    xSemaphoreGive(irLock);
}

// For other tasks: copies the latest full image (768 temperatures in C, row by row, 32 per row), the sensor
// temperature and the image number. Returns false until the first full image exists.
static inline bool irArrayGetLatest(float *to, float *ta, uint32_t *seq)
{
    if (irLock == NULL || xSemaphoreTake(irLock, pdMS_TO_TICKS(100)) != pdTRUE)
    {
        return false;
    }
    const bool ready = (irPubSeq > 0);
    if (ready)
    {
        memcpy(to, irPubTo, sizeof(irPubTo));
        *ta = irPubTa;
        *seq = irPubSeq;
    }
    xSemaphoreGive(irLock);
    return ready;
}

static inline uint32_t irArraySubpageMs(void)
{
    return irSubpageMs;
}

// One summary line: coldest, hottest and centre (mean of the 4 middle pixels) in C.
static void irArrayLogImage(float ta)
{
    float lo = irTo[0];
    float hi = irTo[0];
    for (unsigned p = 1; p < IR_PIXELS; p++)
    {
        lo = fminf(lo, irTo[p]);
        hi = fmaxf(hi, irTo[p]);
    }
    const float centre = (irTo[11 * IR_COLS + 15] + irTo[11 * IR_COLS + 16] + irTo[12 * IR_COLS + 15] + irTo[12 * IR_COLS + 16]) / 4.0f;
    ESP_LOGI(TAG_IR, "coldest %.1f C, hottest %.1f C, centre %.1f C, sensor %.1f C", lo, hi, centre, ta);
}

// The IR array task: load the calibration once, then convert and publish every subpage.
static void irArrayTask(void *arg)
{
    (void)arg;
    if (irArrayLoadCalibration() != ESP_OK)
    {
        ESP_LOGE(TAG_IR, "No usable calibration - IR task stopped");
        vTaskDelete(NULL); // deleting the calling task does not return
    }

    static uint16_t frame[IR_FRAME_WORDS];
    unsigned seen = 0; // bit n set = subpage n converted at least once
    TickType_t lastLog = xTaskGetTickCount();
    for (;;)
    {
        const esp_err_t err = irArrayGetFrameData(frame);
        if (err == ESP_ERR_NOT_FINISHED)
        {
            continue; // normal right after power-up; the next subpage is fine
        }
        if (err != ESP_OK)
        {
            vTaskDelay(pdMS_TO_TICKS(100)); // bus or sensor error (already logged): brief pause, then retry
            continue;
        }

        const float ta = irArrayConvert(frame);
        seen |= 1u << frame[IR_FRAME_SUBPAGE];
        if (seen == 0x3)
        {
            irArrayPublish(ta);
            if ((xTaskGetTickCount() - lastLog) >= pdMS_TO_TICKS(IR_LOG_EVERY_MS))
            {
                lastLog = xTaskGetTickCount();
                irArrayLogImage(ta);
            }
        }
    }
}

// Starts the IR array task. Call after irArrayInit() succeeded.
static inline esp_err_t irArrayStart(void)
{
    irLock = xSemaphoreCreateMutex();
    if (irLock == NULL)
    {
        return ESP_ERR_NO_MEM;
    }
    if (xTaskCreatePinnedToCore(irArrayTask, "irArray", IR_TASK_STACK, NULL, IR_TASK_PRIORITY, NULL, IR_TASK_CORE) != pdPASS)
    {
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

#endif // IR_ARRAY_H

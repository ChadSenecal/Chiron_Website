// main.c - sensor board firmware entry point
//
// Organization: one header per sensor (plus one for the web server). main.c includes them, creates the buses the
// sensors share, calls each init function, then starts the tasks.
//   irArray.h    MLX90640ESF-BAA thermal IR array   ESP_SCL / ESP_SDA bus (shared, created here)   (active)
//   camera.h     OV5640 Adafruit breakout           cmrSCL / cmrSDA bus (its own, created in camera.h) + DVP  (active)
//   mics4514.h   MiCS-4514 gas sensor               ADC1: IO6 VRED, IO7 VNOx; IO47 PRE_S (OX preheat)   (active)
//   webServer.h  Wi-Fi + HTTP page that shows all three on another device   (active)
//   next:        SHT45 (same bus as the IR array) - same pattern, one header
#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "driver/i2c_master.h"

// ---- Sensor headers ------------------------------------------------------------------------------
#include "irArray.h"   // MLX90640ESF-BAA, I2C address 0x33
#include "camera.h"    // OV5640, SCCB address 0x3C, 8-bit DVP, breakout's own 24 MHz clock
#include "mics4514.h"  // MiCS-4514, RED and OX elements on ADC1
#include "webServer.h" // Wi-Fi access point + http://192.168.4.1/

// ---- Sensor I2C bus: schematic nets ESP_SCL / ESP_SDA, shared by the IR array and (later) the SHT45 ----
#define SENSOR_I2C_PORT I2C_NUM_0
#define SENSOR_SCL_IO 38 // ESP_SCL
#define SENSOR_SDA_IO 1  // ESP_SDA

static const char *TAG_MAIN = "MAIN";

void app_main(void)
{
    // 1. Shared sensor bus. One bus handle, one device handle per sensor (ESP-IDF bus-device model).
    i2c_master_bus_handle_t sensorBus = NULL;
    const i2c_master_bus_config_t sensorBusConfig = {
        .i2c_port = SENSOR_I2C_PORT,
        .scl_io_num = SENSOR_SCL_IO,
        .sda_io_num = SENSOR_SDA_IO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,                 // "typically value is 7" [ESP-IDF v6.1 i2c_master.h L31]
        .flags.enable_internal_pullup = false, // the board has external 4.7 kOhm pull-ups on ESP_SCL and ESP_SDA
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&sensorBusConfig, &sensorBus));
    ESP_LOGI(TAG_MAIN, "Sensor I2C bus ready (SCL = IO%d, SDA = IO%d)", SENSOR_SCL_IO, SENSOR_SDA_IO);

    // 2. Sensors - one init call per sensor header, then its task.
    //    The camera loads ~330 registers over its own bus before the IR task starts, so the IR bus is quiet during that
    //    load: on the board, the load failed 10 ms after the IR task's first transfer, and on the module IO1 (ESP_SDA)
    //    is the pin next to IO2 (cmrSCL) [ESP32-S3-WROOM-1 datasheet, pin definitions].
    //    The gas sensor starts first: its preheat and warm-up are timed from its start (mics4514.h).
    if (mics4514Init() != ESP_OK)
    {
        ESP_LOGE(TAG_MAIN, "Gas sensor did not start - the web page will show it as not running");
    }
    const bool irReady = (irArrayInit(sensorBus) == ESP_OK);
    if (cameraInit() != ESP_OK)
    {
        ESP_LOGE(TAG_MAIN, "Camera did not start - the web page will show it as not available");
    }
    if (!irReady || irArrayStart() != ESP_OK)
    {
        ESP_LOGE(TAG_MAIN, "IR array did not start - the web page will say it is waiting for an image");
    }

    // 3. Wi-Fi and the web page
    if (webServerStart() != ESP_OK)
    {
        ESP_LOGE(TAG_MAIN, "Web server did not start");
    }
    // app_main returns here; the IR and gas tasks, Wi-Fi and the HTTP server keep running in their own tasks
}

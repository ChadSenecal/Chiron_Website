# Melexis MLX90640 library, unmodified (Apache-2.0, see LICENSE)
# Source: https://github.com/melexis/mlx90640-library, commit f6be7ca (7 Feb 2023)
# The I2C driver functions it calls (MLX90640_I2CRead, MLX90640_I2CWrite, ...) are implemented in main/irArray.h.
idf_component_register(SRCS "MLX90640_API.c"
                       INCLUDE_DIRS "include")
